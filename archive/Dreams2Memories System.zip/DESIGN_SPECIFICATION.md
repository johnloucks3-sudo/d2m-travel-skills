# 🎨 Dreams2Memories v2.0 Design Specification
## Visual Architecture & Brand Guidelines

---

## 📐 Design Philosophy

**Warm. Personal. Unforgettable.**

This system creates luxury itineraries that feel **handcrafted, not automated**. Every design choice communicates care, expertise, and personalization.

---

## 🎭 Visual Hierarchy

### Page Structure

```
┌─────────────────────────────────────────────┐
│                                             │
│            HERO SECTION                     │
│         (Logo, Client Name, Dates)          │
│            Warm Navy + Gold                 │
│                                             │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│                                             │
│    QUICK REFERENCE CARDS (4 cards)          │
│    (Flights, Accommodations, Transfers)     │
│        Cream backgrounds, clean text        │
│                                             │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│                                             │
│    EXPANDABLE INFO SECTIONS                 │
│    (Packing, Currency, Health, Tech, Food)  │
│        Accordion with smooth animations     │
│                                             │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│                                             │
│         DAY-BY-DAY CARDS                    │
│    (Hero Image + Narrative + Details)       │
│    (Insider Tips, Timing, Weather)          │
│                                             │
└─────────────────────────────────────────────┘
│                                             │
│         [Repeat for each day]               │
│                                             │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│                                             │
│      AGENT MESSAGE + CONTACT SECTION        │
│       (Photo, Name, Phone, Email)           │
│      Warm Navy + Gold + Personal Tone       │
│                                             │
└─────────────────────────────────────────────┘
```

---

## 🎨 Color Palette

### Primary Colors
```
Gold (Accents)          #d4af37  ━━━━━━━━━
Dark Navy (Headers)     #1a2744  ━━━━━━━━━
Warm Cream (BG)         #faf8f3  ━━━━━━━━━
```

### Secondary Colors
```
Ocean Teal              #2a8b96  ━━━━━━━━━  (Timing, clickable)
Accent Peach            #d5a583  ━━━━━━━━━  (Borders, highlights)
Sand (Dividers)         #e8dcc8  ━━━━━━━━━  (Subtle separation)
Light Gray (Text)       #666666  ━━━━━━━━━  (Body copy)
```

### Use Cases
- **Gold (#d4af37):** Section dividers, day numbers, badge accents, agent contact highlights
- **Dark Navy (#1a2744):** Headers, hero section background, text emphasis
- **Warm Cream (#faf8f3):** Backgrounds for breathing room, card backgrounds, accordion triggers
- **Ocean Teal (#2a8b96):** Interactive elements (accordion headers on hover), timing info
- **Accent Peach (#d5a583):** Card left borders, secondary visual interest

---

## 🔤 Typography Stack

### Display Font
**Cormorant Garamond** (serif, elegant)
- Hero heading: 60px, weight 700
- Section titles: 28px, weight 600
- Day numbers: 55px, weight 900
- Agent name: 26px, weight 700

*Why:* Sophisticated, luxury feel. Reminiscent of high-end travel magazines.

### Body Font
**Lora** (serif, readable warmth)
- Narratives: 16px, weight 400
- Body text: 15px-16px
- Accordion headers: 16px, weight 600

*Why:* Warm, approachable serif. Easy to read on screen AND in print.

### UI Font
**Montserrat** (sans-serif, clean)
- Labels: 12px-14px, weight 600, all-caps, letter-spacing 1-2px
- Timing info: 13px, all-caps
- Badges: 11px, weight 600

*Why:* Modern, organized. Creates visual separation from narrative prose.

---

## 📐 Spacing & Layout

### Desktop (1100px max-width)
```
Header: 60px padding top/bottom
Section: 60px margin between sections
Cards: 25px gap
Content padding: 40px
```

### Tablet (768px breakpoint)
```
Header: 40px padding
Cards: 30px padding
Layout: Single column (stack)
Images: 250px height
```

### Mobile (480px breakpoint)
```
Header: 30px padding
Section title: 1.5rem (down from 2.5rem)
Images: 200px height
Cards: 20px padding
Spacing: 30px between sections (down from 60px)
```

---

## 🖼️ Image Specifications

### Hero Section Images (Day Cards)
- **Dimensions:** Full width, 350px height (desktop)
- **Aspect Ratio:** 16:9 or wider
- **Quality:** High resolution (min 1920px wide)
- **Overlay:** Subtle dark gradient (bottom → transparency)
- **Load Behavior:** Lazy loading on scroll

### Agent Headshot
- **Dimensions:** 140px circle
- **Border:** 4px gold (#d4af37)
- **Style:** Professional, warm expression, shoulder up
- **Shadow:** 0 8px 25px rgba(0,0,0,0.3)

### Logo
- **Dimensions:** Max 80px height (responsive down to 60px)
- **Style:** PNG with transparency
- **Positioning:** Centered in hero, above tagline

---

## ✨ Interactive Elements

### Accordion Sections

**Closed State:**
```
┌─────────────────────────────────────────────┐
│ 📋 What to Pack & Dress Codes        [▼]   │
└─────────────────────────────────────────────┘
```
- Background: Linear gradient (cream → light sand)
- Font: 16px Lora, weight 600
- Cursor: pointer
- Transition: All 0.3s ease

**Open State:**
```
┌─────────────────────────────────────────────┐
│ 📋 What to Pack & Dress Codes        [▲]   │
├─────────────────────────────────────────────┤
│ Climate Preview: Tropical climate with      │
│ warm temperatures and gentle sea breezes.   │
│                                             │
│ Casual Wear: Lightweight cotton, linens...  │
│                                             │
└─────────────────────────────────────────────┘
```
- Background: Gold gradient (header) → white (content)
- Animation: slideDown 0.3s ease
- Border-top: Separates header from content

### Hover States
- **Cards:** Light shadow lift + subtle translateY(-2px)
- **Links:** Gold underline + opacity change
- **Accordion Headers:** Background color deepens

---

## 📱 Responsive Breakpoints

### Desktop-First Approach

```css
/* Default: 1100px max-width container */

@media (max-width: 768px) {
  /* Tablet: Stack to 1 column */
  /* Reduce padding by 25% */
  /* Images: 250px height */
}

@media (max-width: 480px) {
  /* Mobile: Tight spacing */
  /* Single column, minimal padding */
  /* Images: 200px height */
  /* Font sizes: -15-20% */
}
```

---

## 🖨️ Print Optimization

### Print-Specific Changes
```css
@media print {
  /* All accordions expanded */
  .accordion-content { display: block !important; }
  
  /* Remove accordion toggles */
  .accordion-toggle { display: none; }
  
  /* Page break control */
  .day-card { page-break-inside: avoid; }
  
  /* Remove interactive indicators */
  .accordion-header { background: cream; cursor: default; }
}
```

### Print Preview Considerations
- Colors convert to grayscale-friendly (limited gold/navy)
- Ensure sufficient contrast in B&W printing
- URLs display as underlined text
- No shadow effects (cleaner print)

---

## 🌟 Component Examples

### Quick Reference Card

```
┌─────────────────────────────┐
│ ✈️ PRE-CRUISE TRAVEL        │
│                             │
│ [🟢 Confirmed]              │
│                             │
│ Departure Flight            │
│ UA456 Denver-Rome May 15    │
│                             │
│ Arrival at Port             │
│ Check-in time: 1:00 PM      │
└─────────────────────────────┘
```
- Border-left: 5px gold
- Padding: 30px
- Box-shadow: 0 4px 15px rgba(0,0,0,0.08)
- Hover: Box-shadow deepens, slight lift

### Day Card Structure

```
╔════════════════════════════════════════╗
║  [Hero Image - Full Width]             ║
╠════════════════════════════════════════╣
║                                        ║
║ 1    Rome                              ║
║      ⏰ Arrive 4:00 PM • Depart 11:59 PM│
║                                        ║
║ Narrative: Ancient cobblestones echo   ║
║ with 2,000 years of history. Climb...  ║
║                                        ║
║ ┌──────────────────────────────────┐   ║
║ │ Location:    Rome, Italy         │   ║
║ │ Timing:      All ashore by 5 PM  │   ║
║ │ Weather:     Sunny, 72°F         │   ║
║ └──────────────────────────────────┘   ║
║                                        ║
║ ✨ Insider Recommendations            ║
║ ┌──────┐ ┌──────┐ ┌──────┐            ║
║ │Must  │ │Dining│ │Local │            ║
║ │See   │ │Gem   │ │Secret│            ║
║ │Colo- │ │Flavio│ │Avoid │            ║
║ │sseum │ │al V. │ │tourist│           ║
║ └──────┘ └──────┘ └──────┘            ║
║                                        ║
╚════════════════════════════════════════╝
```

---

## 💡 Design Principles

### 1. Breathing Room Over Density
- Large whitespace sections
- Cards separated by 25-40px gaps
- Never cramped or cluttered

### 2. Warm Typography
- Serif fonts for narrative (feels personal)
- Sans-serif for UI (feels organized)
- Generous line-height (1.6-1.9)

### 3. Visual Hierarchy Through Scale
- Hero heading: 4rem
- Section titles: 2.5rem
- Day numbers: 3.75rem (emphasis)
- Body text: 1rem

### 4. Personalization Over Template
- Client name prominently placed
- Agent photo & personal message
- Custom narratives per port
- Individual day cards (not a dry list)

### 5. Luxury Through Restraint
- Limited color palette (3 primary + 2 secondary)
- Elegant fonts (not too many typefaces)
- Generous padding, not cramped
- Quality over quantity

---

## 🎯 Accessibility Considerations

### Color Contrast
- Text: WCAG AA compliant (4.5:1 minimum)
- Headers: High contrast (navy on cream)
- Interactive: Teal easily distinguished from backgrounds

### Typography
- Minimum 14px for body text
- Line-height: 1.6+ for readability
- Sans-serif for small UI text (clarity)

### Responsive
- Touch targets: 44px minimum (mobile buttons)
- Readable at all zoom levels (up to 200%)
- Works with screen readers (semantic HTML)

---

## 📊 Performance Metrics

### File Sizes
- HTML Template: ~33KB (gzipped: ~8KB)
- Typical Full Itinerary: ~200-400KB (with images)
- PDF Output: 2-5MB (depends on image quality)

### Load Times
- Desktop: <2 seconds (local)
- Mobile: <3 seconds (with good internet)
- PDF generation: 30-60 seconds per itinerary

### Browser Support
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ⚠️ IE11: Not supported (uses modern CSS)

---

## 🚀 Enhancement Ideas (Future v3.0)

1. **Interactive Map Integration**
   - Leaflet.js for port locations
   - Click to see local restaurants/attractions

2. **Client Portal**
   - Store past itineraries
   - Easy sharing (no email attachment)
   - Real-time updates (ship location, weather)

3. **Mobile App**
   - Offline access
   - Notification reminders
   - Built-in currency converter

4. **Voice Narratives**
   - Audio guide per port
   - Spotify/Apple Music integration
   - AI voice (natural, warm tone)

5. **Social Sharing**
   - Share highlights to Instagram
   - Family group coordination
   - Packing checklist app sync

---

**Design v2.0** | Created: 2026-03-03 | Ready for Production ✅
