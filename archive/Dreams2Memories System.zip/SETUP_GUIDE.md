# 🎨 Dreams2Memories v2.0 - Luxury Itinerary System
## Setup & Implementation Guide

---

## 📋 Overview

This system generates **warm, personal, responsive luxury cruise itineraries** in two formats:
- **Interactive HTML** (for email, web, phone/tablet viewing with expandable accordion sections)
- **Print-optimized PDF** (for printing and PDF distribution)

Both formats pull dynamic data from your Google Sheets and generate AI-enhanced narratives + imagery.

---

## 🛠️ Installation & Prerequisites

### System Requirements
- **OS:** Linux/macOS/Windows (Python 3.9+)
- **Hardware:** Ryzen 7 / 8GB RAM minimum (you're set!)
- **Storage:** 2GB for output files

### Python Dependencies

```bash
pip install --break-system-packages \
  gspread \
  google-auth \
  google-auth-oauthlib \
  google-auth-httplib2 \
  google-api-python-client \
  weasyprint \
  openai \
  requests \
  Pillow \
  pdf2image \
  pytesseract
```

### macOS/Linux Specific
```bash
# For WeasyPrint PDF rendering
apt-get install libffi-dev libcairo2 libpango-1.0-0 libpango-cairo-1.0-0 libgdk-pixbuf2.0-0 shared-mime-info fonts-dejavu

# For image OCR (optional, for PDF processing)
apt-get install tesseract-ocr
```

---

## 📂 Directory Structure

Create this structure in your home directory:

```
~/Dreams2Memories/
├── Agency_Logo.png                 # Your Dreams2Memories logo
├── John_Headshot.jpg               # Your professional headshot
├── dreams2memories_itinerary.html  # Main HTML template
├── thunderbird_v2_integration.py   # Python generator script
└── credentials.json                # Google Service Account (from Sheets API)
```

**Also ensure:**
```
~/Thunderbird/
└── credentials.json                # Same Google credentials file
```

---

## 🔐 Google Sheets Configuration

### 1. Google Sheets Setup
Your **Booking Master** tab should have these columns:

| Column | Type | Example |
|--------|------|---------|
| Client_Name | Text | John Smith |
| Trip_Name | Text | Mediterranean Luxury Voyage |
| Supplier | Text | Silversea |
| Start_Date | Date | May 15, 2026 |
| End_Date | Date | May 30, 2026 |
| Confirmation_Number | Text | SV123456 |
| Outbound_Flight | Text | UA456 Denver-Rome May 15 |
| Return_Flight | Text | UA457 Rome-Denver May 30 |
| Cabin_Number | Text | 1234 |
| Port_Arrival | Text | Rome, May 15 at 4:00 PM |
| Dining_Prefs | Text | Vegetarian options requested |
| Special_Requests | Text | Celebration: 25th Anniversary |
| Weather_Forecast | Text | Mediterranean spring—mild, sunny |
| AI_Uncategorized_Notes | Text | Any additional details |

Your **Daily Itinerary** tab should have:

| Column | Type | Example |
|--------|------|---------|
| Confirmation_Number | Text | SV123456 |
| Day | Number | 1 |
| Port_Location | Text | Rome |
| Arrive | Time | 4:00 PM |
| Depart | Time | 11:59 PM |
| Romance_Narrative | Text | *AI-generated prose* |
| Romance_Short | Text | ancient history |
| Image_1_URL | URL | https://... |
| Weather | Text | Sunny, 72°F |
| Recommended_Activity | Text | Colosseum, Vatican |
| Best_Restaurant | Text | Flavio al Velavevodetto |
| Local_Tip | Text | Avoid tourist areas near Trevi; explore neighborhoods west of Termini |

### 2. Service Account Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a **Service Account** for your Sheets access
3. Download the JSON key file → save as `~/Thunderbird/credentials.json`
4. **Share your Google Sheet** with the service account email (ending in @iam.gserviceaccount.com)

---

## 🖼️ Image Assets

### Logo Setup
- **File:** `Agency_Logo.png`
- **Size:** Recommended 500x200px
- **Format:** PNG with transparent background
- **Location:** `~/Dreams2Memories/Agency_Logo.png`

### Agent Headshot
- **File:** `John_Headshot.jpg`
- **Size:** Recommended 500x600px (portrait)
- **Format:** JPEG
- **Requirements:** Professional, warm, welcoming
- **Location:** `~/Dreams2Memories/John_Headshot.jpg`

---

## 🎯 Usage

### Generate an Itinerary

```bash
cd ~/Dreams2Memories
python thunderbird_v2_integration.py
```

**Follow the prompts:**
```
==============================================================
   DREAMS2MEMORIES: THUNDERBIRD OS v2.0
   Luxury Itinerary Generation System
==============================================================
[1] Generate New Itinerary (HTML + PDF)
[2] Process PDFs & Extract Booking Data
[3] Exit
==============================================================

Select option: 1
Enter client name (exact from Sheet): John Smith
```

**Output:**
```
✅ Found master booking for John Smith
✅ Found 15 itinerary days
✍ Generating narrative for Day 1: Rome...
✅ Narrative saved
🎨 Fetching image for Rome...
✅ Image saved
[... continues for all days ...]
✨ MASTERPIECE COMPLETE ✨
📄 Open HTML for interactive version: ~/Documents/Luxury_Itineraries/ITINERARY_John_Smith.html
📕 Print/email PDF version: ~/Documents/Luxury_Itineraries/ITINERARY_John_Smith.pdf
```

### Output Files

**HTML Version** (`ITINERARY_John_Smith.html`)
- ✅ Fully responsive (mobile, tablet, desktop)
- ✅ Interactive accordion sections
- ✅ Warm, personal typography
- ✅ Expandable practical information
- ✅ Works offline (embedded images)
- 📧 Send via email or host on web

**PDF Version** (`ITINERARY_John_Smith.pdf`)
- ✅ Print-optimized
- ✅ All information visible (accordions expanded)
- ✅ Professional formatting
- ✅ Ink-efficient colors
- 🖨️ Print or archive

---

## 🎨 Customization

### Brand Colors
Edit the `:root` CSS variables in `dreams2memories_itinerary.html`:

```css
:root {
    --gold: #d4af37;              /* Accent color */
    --dark-navy: #1a2744;         /* Dark backgrounds */
    --warm-cream: #faf8f3;        /* Cream backgrounds */
    --ocean: #2a8b96;             /* Teal accents */
    --accent-peach: #d5a583;      /* Secondary accent */
}
```

### Typography
Font families are defined at the top of the CSS:
- **Display:** Cormorant Garamond (elegant, serif)
- **Body:** Lora (readable, warm serif)
- **UI:** Montserrat (clean, sans-serif)

### Additional Customization
Edit `thunderbird_v2_integration.py`:

```python
class Config:
    AGENT_NAME = "John Loucks"              # Your name
    AGENT_PHONE = "(719) 291-0742"          # Your phone
    AGENT_EMAIL = "jl3lovegrouptravel@gmail.com"  # Your email
    AGENCY_WEBSITE = "www.lovegrouptravel.com"    # Your website
```

---

## 📧 Distribution

### Email Distribution
1. Open the HTML file in a browser
2. **Save as PDF** (Cmd+P / Ctrl+P → Save as PDF)
3. Attach both HTML and PDF to email:
   ```
   Subject: Your [Trip_Name] Luxury Itinerary - [Client_Name]
   
   Dear [Client_Name],
   
   Your exclusive itinerary is attached. View in your browser for interactive features,
   or print the PDF for your travel folder.
   
   Warm regards,
   John
   ```

### Web Distribution
1. Upload `ITINERARY_John_Smith.html` to your website server
2. Share the link with clients
3. Can also upload to Google Drive for easy sharing

### Print Distribution
1. Use the PDF version for high-quality printing
2. Recommended: Color laser printer for best results
3. Consider spiral binding for premium presentation

---

## 🐛 Troubleshooting

### "Service Account not authorized"
- Verify `credentials.json` is in `~/Thunderbird/`
- Check that the service account email is shared on your Google Sheet
- Ensure you have Editor permissions on the spreadsheet

### "Client not found in Master tab"
- Check exact spelling of client name in Sheets
- Ensure the name is in the `Client_Name` column
- Remove leading/trailing spaces

### Images not displaying
- Verify URLs are valid (test in browser)
- For Pexels/Google Image Search: requires internet connection
- For Drive images: ensure file is shared publicly or accessible by service account

### PDF generation fails
- Install missing fonts: `apt-get install fonts-dejavu` (Linux)
- Check available disk space: `df -h`
- Ensure WeasyPrint is installed: `pip install --break-system-packages weasyprint`

### Accordion not working in interactive HTML
- JavaScript must be enabled in browser
- Check browser console for errors (F12)
- Ensure you're opening the file locally, not from a restricted source

---

## 💡 Pro Tips

### Automate Monthly Generation
Create a shell script `generate_all_clients.sh`:

```bash
#!/bin/bash
cd ~/Dreams2Memories
echo "1" | python thunderbird_v2_integration.py <<< "John Smith"
echo "1" | python thunderbird_v2_integration.py <<< "Jane Doe"
echo "1" | python thunderbird_v2_integration.py <<< "Bob Johnson"
```

Then run: `bash generate_all_clients.sh`

### Batch PDF Conversion
```bash
for html in ~/Documents/Luxury_Itineraries/*.html; do
    weasyprint "$html" "${html%.html}.pdf"
done
```

### Monitor Generation Logs
```bash
python thunderbird_v2_integration.py 2>&1 | tee generation.log
```

---

## 🎓 Architecture Notes

### Template System
- Uses **Jinja2** for dynamic content injection
- Variables enclosed in `{{ }}` are replaced from Sheets data
- Conditional sections (`{% if %}`) for optional content

### Responsive Design
- **Mobile-first** CSS approach
- Breakpoints: 768px (tablet), 480px (phone)
- Flexbox + CSS Grid for layouts
- All images optimize automatically for screen size

### Image Hierarchy
1. **Curated Art:** Drive folder (`Titan_Art_[Port].png`)
2. **Sniper Vision:** Custom Google Image Search
3. **Pexels:** Free stock photography API
4. **Unsplash:** Fallback default image

### AI Integration
- **Narratives:** Gemini 2.5 Flash (fast, cost-effective)
- **Fallback:** Groq LLaMA (if Gemini unavailable)
- **Cost:** ~$0.50 per itinerary (with current API pricing)

---

## 📞 Support

For questions or issues:
- **Email:** jl3lovegrouptravel@gmail.com
- **Phone:** (719) 291-0742
- **Website:** www.lovegrouptravel.com

---

## 📄 License & Attribution

This system was custom-built for Dreams2Memories Travel. All code is proprietary and confidential.

**Version:** 2.0  
**Last Updated:** 2026-03-03  
**Status:** Production Ready ✅
