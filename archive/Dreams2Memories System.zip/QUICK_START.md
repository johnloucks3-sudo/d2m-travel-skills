# 🚀 Dreams2Memories Quick Start
## One-Page Reference Card

---

## ⚡ Generate an Itinerary (30 seconds)

```bash
cd ~/Dreams2Memories
python thunderbird_v2_integration.py
# Select: 1
# Enter: Client name (exact from Sheet)
# Wait: 2-3 minutes
# Output: HTML + PDF in ~/Documents/Luxury_Itineraries/
```

---

## 📁 File Locations

| File | Location | Purpose |
|------|----------|---------|
| HTML Template | `~/Dreams2Memories/dreams2memories_itinerary.html` | Main template (DON'T DELETE) |
| Python Script | `~/Dreams2Memories/thunderbird_v2_integration.py` | Generator (run this) |
| Logo | `~/Dreams2Memories/Agency_Logo.png` | Brand logo |
| Headshot | `~/Dreams2Memories/John_Headshot.jpg` | Your photo |
| Credentials | `~/Thunderbird/credentials.json` | Google Sheets access |
| Output | `~/Documents/Luxury_Itineraries/` | Generated files |

---

## 📊 Google Sheet Tabs

### Tab 1: "Booking Master"
**One row per client booking**

Required columns:
- `Client_Name` - Exact spelling
- `Trip_Name` - Trip title
- `Supplier` - Cruise line name
- `Start_Date` - Trip start
- `End_Date` - Trip end
- `Confirmation_Number` - Matches Daily Itinerary tab

Optional (for detailed itineraries):
- `Outbound_Flight`, `Return_Flight`
- `Cabin_Number`, `Port_Arrival`
- `Dining_Prefs`, `Special_Requests`
- `Weather_Forecast`

### Tab 2: "Daily Itinerary"
**Multiple rows per booking (one per day)**

Required columns:
- `Confirmation_Number` - Matches Master tab
- `Day` - Day number (1, 2, 3...)
- `Port_Location` - Port/destination name
- `Arrive` - Arrival time (e.g., "4:00 PM")
- `Depart` - Departure time (e.g., "11:59 PM")

AI-generated columns (auto-filled):
- `Romance_Narrative` - 3-4 sentences about port
- `Romance_Short` - Short search query (e.g., "ancient history")
- `Image_1_URL` - High-quality image URL

Optional:
- `Weather` - Weather forecast
- `Recommended_Activity` - Must-see attraction
- `Best_Restaurant` - Local dining tip
- `Local_Tip` - Insider knowledge

---

## 🎨 Output Preview

### Interactive HTML Features
✅ Accordion sections (click to expand)
✅ Responsive on phone/tablet/desktop
✅ Beautiful typography & warm colors
✅ Day-by-day cards with hero images
✅ Agent photo & contact info
✅ Practical information (dress codes, currencies, etc.)

### PDF Features
✅ All sections expanded & visible
✅ Print-optimized colors
✅ Professional formatting
✅ Page breaks optimized for readability

---

## 🔧 Basic Troubleshooting

### "Client not found"
→ Check spelling in Google Sheet exactly  
→ Ensure `Client_Name` column exists  

### Images not showing
→ Check internet connection  
→ Verify image URLs are valid  
→ May take 30 seconds to load  

### PDF won't generate
→ Run: `pip install --break-system-packages weasyprint`  
→ Check: `df -h` (need 500MB+ disk space)  

### Accordion not working
→ Open HTML file in **Chrome** or **Firefox**  
→ NOT Internet Explorer  
→ JavaScript must be enabled  

### Can't find output files
→ Check: `~/Documents/Luxury_Itineraries/`  
→ Look for: `ITINERARY_[ClientName].html`  
→ And: `ITINERARY_[ClientName].pdf`  

---

## 📧 Email Template

```
Subject: Your Exclusive Itinerary – [Trip_Name]

Dear [Client_Name],

Your personalized luxury itinerary is ready! 

View the interactive version in your browser (works on phone, tablet, desktop), or print the PDF for your travel folder. All information you'll need at your fingertips.

Confirmations, timing, practical tips, and my contact info are all included. If anything needs adjustment, just call or email.

Safe travels!

[Your Name]
[Your Phone]
[Your Email]
www.lovegrouptravel.com
```

---

## 🎯 Quality Checklist

Before sending to client:
- [ ] Client name matches Google Sheet exactly
- [ ] All trip dates correct
- [ ] Ship/supplier name accurate
- [ ] Day-by-day timeline complete
- [ ] All images loaded
- [ ] Narratives read well (check for typos)
- [ ] Agent photo displays correctly
- [ ] Contact info is current
- [ ] Test accordion sections (HTML only)
- [ ] Print preview looks good (PDF)

---

## 🚀 One-Command Workflow

**Everything in one shot:**
```bash
cd ~/Dreams2Memories && python thunderbird_v2_integration.py <<< "1" <<< "John Smith" && open ~/Documents/Luxury_Itineraries/ITINERARY_John_Smith.html
```

---

## 💬 Key Contact Info

**For technical issues:**  
Email: jl3lovegrouptravel@gmail.com  
Phone: (719) 291-0742  

**For client support:**  
Website: www.lovegrouptravel.com  
Agency: Love Group Travel  

---

**Version 2.0** | Last updated: 2026-03-03 | Production Ready ✅
