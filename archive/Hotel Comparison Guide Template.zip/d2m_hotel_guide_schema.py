"""
d2m_hotel_guide_schema.py
─────────────────────────────────────────────────────────────
Data schema for hotel_guide.html.j2

Feed an instance of HotelGuideContext into the Jinja2 renderer:

    from jinja2 import Environment, FileSystemLoader
    from weasyprint import HTML
    from d2m_hotel_guide_schema import HotelGuideContext, build_context

    env = Environment(loader=FileSystemLoader("templates/"))
    tmpl = env.get_template("hotel_guide.html.j2")
    html = tmpl.render(**context.to_dict())
    HTML(string=html).write_pdf("output.pdf")
─────────────────────────────────────────────────────────────
"""

from dataclasses import dataclass, field
from typing import Optional


# ── Helpers ────────────────────────────────────────────────

def fmt_usd(amount: float) -> str:
    """Format a float as $X,XXX — all currency pre-formatted in Python."""
    return f"${amount:,.0f}"


# ── Sub-objects ─────────────────────────────────────────────

@dataclass
class MetaItem:
    """One key/value pair on the cover page meta strip."""
    label: str          # e.g. "Dates"
    value: str          # e.g. "July 3–6, 2026"


@dataclass
class DocMeta:
    """Cover page and global document metadata."""
    destination:    str                     # e.g. "Venice"
    subtitle:       str                     # e.g. "Five Exceptional Hotels for Your Stay"
    doc_type:       str                     # e.g. "Curated Hotel Selection"
    travel_period:  str                     # e.g. "July 2026"  (used in headers/footers)
    prepared_date:  str                     # e.g. "March 2026"
    nights:         int                     # e.g. 3
    client_name:    Optional[str] = None    # e.g. "the McLeod Party" — omit for generic
    logistics_title: str = "Getting Around" # Override for cruise, rail, etc.
    meta_items:     list[MetaItem] = field(default_factory=list)


@dataclass
class DescriptionSection:
    """One labeled text block inside a hotel card."""
    label: str   # e.g. "The Hotel" or "The Neighborhood"
    text:  str   # Plain text — HTML entities OK, no raw tags


@dataclass
class PriceBox:
    """The gold (or prestige/purple) price callout on a hotel card."""
    room_label: str       # e.g. "Our Pick · Double Deluxe B&B"
    amount:     str       # Pre-formatted — use fmt_usd()  e.g. "$977"
    sub:        str       # e.g. "3 nights · breakfast included"
    note:       str = ""  # e.g. "Free cancellation until June 25"
    prestige:   bool = False  # True → purple prestige box (over-budget tier)


@dataclass
class ContactInfo:
    """Contact block beneath the price box."""
    email:     str
    phone:     str
    highlight: str = ""   # Bold top line, e.g. "Best Value Pick"
    note:      str = ""   # Small faint note, e.g. "+ $13/person/night city tax"


@dataclass
class RoomRate:
    """One row in the room options table."""
    room_name: str
    price:     str        # Pre-formatted, e.g. "$977"
    board:     str = ""   # e.g. "Breakfast" or "Room Only" — displayed inline
    is_pick:   bool = False  # Highlights the row in gold


@dataclass
class Landmark:
    """One row in the distance-to-landmarks table."""
    name:       str
    directions: str
    distance:   str       # e.g. "~400m" or "~25 min"
    nearest:    bool = False  # Shows gold "NEAREST" badge


@dataclass
class Hotel:
    """Full data for one hotel card page."""
    name:        str
    stars:       int                       # 1–5 (renders ★ characters)
    address:     str
    district:    str
    phone:       str
    photos:      list[str]                 # base64 data URIs — index 0 = main, 1-2 = sidebar
    description_sections: list[DescriptionSection]
    price_box:   PriceBox
    contact:     ContactInfo
    landmarks:   list[Landmark]
    room_rates:  list[RoomRate] = field(default_factory=list)
    rates_caption: str = "3 nights"       # Caption above rates table
    rates_note:  str = ""                 # Italic note below rates table
    stars_label: str = ""                 # e.g. "LUXURY" or "SLH · SMALL LUXURY HOTELS"


@dataclass
class CompRow:
    """One row in the side-by-side comparison table."""
    hotel:        str
    district:     str
    stars:        int
    pick:         str          # e.g. "Double Deluxe B&B"
    price:        str          # Pre-formatted, e.g. "$977"
    cancel_text:  str          # e.g. "Free to Jun 25" or "Non-refundable"
    cancel_class: str          # "ok" | "no" | "tbd"  → CSS class
    nearest:      str          # e.g. "Bridge of Sighs · 100m"
    badge_text:   str          # e.g. "Best Value"
    badge_class:  str          # "value"|"location"|"experience"|"luxury"|"local"
    prestige:     bool = False # True → purple price text


@dataclass
class RecCard:
    """One recommendation card below the comparison table (max 3)."""
    label:       str    # e.g. "★ Best Value"
    hotel:       str
    price:       str    # e.g. "$977 · 3 nights B&B"
    description: str


@dataclass
class TransportCard:
    """One card in the 2×2 transport grid."""
    icon:  str   # Emoji, e.g. "🚶"
    title: str
    body:  str   # HTML allowed — wrap highlights in <span class="transport-highlight">


@dataclass
class InfoBox:
    """The wide info box beneath the transport grid."""
    icon: str    # Emoji
    text: str    # HTML allowed — wrap <strong> for bold labels


@dataclass
class HotelGuideContext:
    """Root context object — pass .to_dict() to template.render()"""
    doc:        DocMeta
    hotels:     list[Hotel]
    comparison: list[CompRow]         = field(default_factory=list)
    picks:      list[RecCard]         = field(default_factory=list)   # max 3
    logistics:  list[TransportCard]   = field(default_factory=list)
    info_box:   Optional[InfoBox]     = None
    footnote:   Optional[str]         = None

    def to_dict(self) -> dict:
        """Serialize to a flat dict suitable for Jinja2 render(**ctx)."""
        return {
            "doc":        self.doc,
            "hotels":     self.hotels,
            "comparison": self.comparison,
            "picks":      self.picks,
            "logistics":  self.logistics,
            "info_box":   self.info_box,
            "footnote":   self.footnote,
        }


# ── Renderer helper ────────────────────────────────────────

def render_to_pdf(
    context: HotelGuideContext,
    output_path: str,
    template_dir: str = "templates/",
    template_name: str = "hotel_guide.html.j2",
) -> None:
    """
    Full render pipeline:
      1. Jinja2 → HTML string
      2. WeasyPrint → PDF on disk

    Usage:
        render_to_pdf(context, "output/Venice_McLeod_Jul2026.pdf")
    """
    from jinja2 import Environment, FileSystemLoader
    from weasyprint import HTML

    env = Environment(
        loader=FileSystemLoader(template_dir),
        autoescape=False,   # We control input — disable for HTML safety
    )
    tmpl = env.get_template(template_name)
    html_string = tmpl.render(**context.to_dict())
    HTML(string=html_string, base_url=template_dir).write_pdf(output_path)
    print(f"✓ PDF written → {output_path}")


# ── Example / smoke test ────────────────────────────────────

if __name__ == "__main__":
    """
    Minimal example showing the data shape.
    Replace with real data and photo base64 strings.
    """
    import base64

    # Placeholder 1×1 pixel transparent PNG for smoke test
    BLANK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="

    ctx = HotelGuideContext(
        doc=DocMeta(
            destination="Venice",
            subtitle="Five Exceptional Hotels for Your Stay",
            doc_type="Curated Hotel Selection",
            travel_period="July 2026",
            prepared_date="March 2026",
            nights=3,
            client_name="the McLeod Party",
            meta_items=[
                MetaItem("Dates",    "July 3–6, 2026"),
                MetaItem("Duration", "3 Nights"),
                MetaItem("Guests",   "2 Guests"),
                MetaItem("All rates","USD"),
            ],
        ),
        hotels=[
            Hotel(
                name="Liassidi Palace",
                stars=4,
                address="Ponte dei Greci, 3405",
                district="Castello District",
                phone="+39 041 520 5658",
                photos=[BLANK, BLANK, BLANK],
                description_sections=[
                    DescriptionSection("The Hotel",        "A restored 15th-century palazzo with just 26 rooms."),
                    DescriptionSection("The Neighborhood", "The Castello sestiere — Venice's most authentically Venetian neighborhood."),
                ],
                price_box=PriceBox(
                    room_label="Our Pick · Double Deluxe B&B",
                    amount=fmt_usd(977),
                    sub="3 nights · breakfast included",
                    note="Free cancellation until June 25",
                ),
                contact=ContactInfo(
                    highlight="Best Value Pick",
                    email="info@liassidipalacehotel.com",
                    phone="+39 041 520 5658",
                    note="+ ~$13/person/night city tax at hotel",
                ),
                room_rates=[
                    RoomRate("Double Deluxe",                        fmt_usd(977),  is_pick=True),
                    RoomRate("Junior Suite Split Level",             fmt_usd(1291)),
                    RoomRate("Junior Suite",                         fmt_usd(1325)),
                    RoomRate("King Romantic Suite — Canal View + Sauna", fmt_usd(1887)),
                ],
                rates_caption="3 nights, breakfast included",
                landmarks=[
                    Landmark("San Giorgio dei Greci", "Literally across the bridge", "~80m · 1 min", nearest=True),
                    Landmark("St. Mark's Square",     "5-min walk south",            "~400m"),
                    Landmark("Bridge of Sighs",       "7-min walk",                  "~500m"),
                    Landmark("Doge's Palace",         "6-min walk",                  "~450m"),
                    Landmark("Rialto Bridge",         "15-min walk through alleys",  "~1.2km"),
                    Landmark("Murano Island",         "Vaporetto from Arsenale (Line 4.1)", "~25 min"),
                ],
            ),
        ],
        comparison=[
            CompRow(
                hotel="Liassidi Palace", district="Castello", stars=4,
                pick="Double Deluxe B&B", price=fmt_usd(977),
                cancel_text="Free to Jun 25", cancel_class="ok",
                nearest="San Giorgio dei Greci · 80m",
                badge_text="Best Value", badge_class="value",
            ),
        ],
        picks=[
            RecCard(
                label="★ Best Value",
                hotel="Liassidi Palace",
                price=f"{fmt_usd(977)} · 3 nights B&B",
                description="15th-century palazzo. 26 intimate rooms. 5 min to St. Mark's. Free cancellation.",
            ),
        ],
        logistics=[
            TransportCard("🚶", "Walking",
                'Venice is a walking city — <span class="transport-highlight">no cars, no buses on the islands.</span>'),
            TransportCard("🚢", "Vaporetto (Water Bus)",
                'A <span class="transport-highlight">3-day pass costs ~$44/person</span> for unlimited rides.'),
        ],
        info_box=InfoBox(
            icon="🗺️",
            text="<strong>Location Context:</strong> All hotels are within Venice's historic center — nothing more than 20 minutes' walk apart.",
        ),
        footnote="⚠ Venice city tax: ~$13/person/night · payable at hotel · not included in quoted rates · All rates in USD",
    )

    render_to_pdf(ctx, "/tmp/d2m_hotel_guide_test.pdf")
